Simple example of simple GET REST server with (cppRESTSDK)[https://github.com/Microsoft/cpprestsdk], built in Ubuntu 14.04

to build in OS X:
```
brew install openssl
brew link openssl --force
```

then run:
```
make
```
